﻿using System.ComponentModel.DataAnnotations;

namespace App.Models
{
    public class MDavila
    {
        public int Id { get; set; }

        public float? Decimal { get; set; }

        [StringLength(10)]
        public required string CadenaCarac { get; set; }

        public required bool decision { get; set; }


        public required DateTime Fecha { get; set; }


        public Carrera Carrera { get; set; }

    }
}
