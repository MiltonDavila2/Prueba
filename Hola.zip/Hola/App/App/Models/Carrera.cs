﻿using System.ComponentModel.DataAnnotations;

namespace App.Models
{
    public class Carrera
    {
        [Key]
        public int Id { get; set; }




        public string NombreCarrera { get; set; }

        public int NumeroSemestres { get; set; }

        public string Campus { get; set; }
    }
}
