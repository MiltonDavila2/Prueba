﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using App.Models;

namespace MiltonDavila.Data
{
    public class MiltonDavilaContext : DbContext
    {
        public MiltonDavilaContext (DbContextOptions<MiltonDavilaContext> options)
            : base(options)
        {
        }

        public DbSet<App.Models.MDavila> MDavila { get; set; } = default!;
    }
}
