﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using App.Models;
using MiltonDavila.Data;

namespace App.Controllers
{
    public class DavilaController : Controller
    {
        private readonly MiltonDavilaContext _context;

        public DavilaController(MiltonDavilaContext context)
        {
            _context = context;
        }

        // GET: Davila
        public async Task<IActionResult> Index()
        {
            return View(await _context.MDavila.ToListAsync());
        }

        // GET: Davila/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var mDavila = await _context.MDavila
                .FirstOrDefaultAsync(m => m.Id == id);
            if (mDavila == null)
            {
                return NotFound();
            }

            return View(mDavila);
        }

        // GET: Davila/Create
        public IActionResult Create()
        {
            return View();
        }

        // POST: Davila/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("Id,Decimal,CadenaCarac,decision,Fecha")] MDavila mDavila)
        {
            if (ModelState.IsValid)
            {
                _context.Add(mDavila);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            return View(mDavila);
        }

        // GET: Davila/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var mDavila = await _context.MDavila.FindAsync(id);
            if (mDavila == null)
            {
                return NotFound();
            }
            return View(mDavila);
        }

        // POST: Davila/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("Id,Decimal,CadenaCarac,decision,Fecha")] MDavila mDavila)
        {
            if (id != mDavila.Id)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(mDavila);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!MDavilaExists(mDavila.Id))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            return View(mDavila);
        }

        // GET: Davila/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var mDavila = await _context.MDavila
                .FirstOrDefaultAsync(m => m.Id == id);
            if (mDavila == null)
            {
                return NotFound();
            }

            return View(mDavila);
        }

        // POST: Davila/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var mDavila = await _context.MDavila.FindAsync(id);
            if (mDavila != null)
            {
                _context.MDavila.Remove(mDavila);
            }

            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool MDavilaExists(int id)
        {
            return _context.MDavila.Any(e => e.Id == id);
        }
    }
}
